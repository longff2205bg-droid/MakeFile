package com.example.anticheat;

import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class AntiCheatPlugin extends JavaPlugin {
    private ACListener listener;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        listener = new ACListener(this);
        getServer().getPluginManager().registerEvents(listener, this);
        getLogger().info("AntiCheatPlugin enabled (1.0.0)");
    }

    @Override
    public void onDisable() {
        getLogger().info("AntiCheatPlugin disabled");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("acreload")) {
            reloadConfig();
            listener.reloadConfig();
            sender.sendMessage("AntiCheat config reloaded.");
            return true;
        }
        return super.onCommand(sender, command, label, args);
    }
}
