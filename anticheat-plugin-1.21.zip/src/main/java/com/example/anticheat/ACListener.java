package com.example.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class ACListener implements Listener {
    private final Plugin plugin;
    private final Map<UUID, Integer> violations = new ConcurrentHashMap<>();

    private double speedThreshold;
    private int speedKickThreshold;
    private double reachThreshold;
    private int reachKickThreshold;
    private int flyKickThreshold;
    private boolean kickOnExceed;
    private boolean announce;

    public ACListener(Plugin plugin) {
        this.plugin = plugin;
        reloadConfig();
        // decay violations over time
        new BukkitRunnable() {
            @Override
            public void run() {
                violations.forEach((uuid, v) -> {
                    int dec = Math.max(0, v - 1);
                    if (dec == 0) violations.remove(uuid);
                    else violations.put(uuid, dec);
                });
            }
        }.runTaskTimer(plugin, 20L*10, 20L*10); // every 10 seconds
    }

    public void reloadConfig() {
        speedThreshold = plugin.getConfig().getDouble("checks.speed.max-horizontal-distance-per-tick", 0.8);
        speedKickThreshold = plugin.getConfig().getInt("checks.speed.violations-to-kick", 8);
        reachThreshold = plugin.getConfig().getDouble("checks.reach.max-reach", 4.5);
        reachKickThreshold = plugin.getConfig().getInt("checks.reach.violations-to-kick", 6);
        flyKickThreshold = plugin.getConfig().getInt("checks.fly.violations-to-kick", 6);
        kickOnExceed = plugin.getConfig().getBoolean("punish.kick_on_exceed", false);
        announce = plugin.getConfig().getBoolean("logging.announce_suspicious", true);
    }

    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        if (!plugin.getConfig().getBoolean("checks.speed.enabled", true)) return;
        Location from = event.getFrom();
        Location to = event.getTo();
        if (to == null) return;
        double dx = to.getX() - from.getX();
        double dz = to.getZ() - from.getZ();
        double horizontal = Math.sqrt(dx*dx + dz*dz);
        Player p = event.getPlayer();
        // Simple check: if horizontal distance per tick > threshold
        if (horizontal > speedThreshold) {
            flagViolation(p, "speed", speedKickThreshold);
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!plugin.getConfig().getBoolean("checks.reach.enabled", true)) return;
        if (!(event.getDamager() instanceof Player)) return;
        if (!(event.getEntity() instanceof Player)) return;
        Player damager = (Player) event.getDamager();
        Player target = (Player) event.getEntity();
        double distance = damager.getLocation().distance(target.getLocation());
        if (distance > reachThreshold) {
            flagViolation(damager, "reach", reachKickThreshold);
        }
    }

    @EventHandler
    public void onToggleFlight(PlayerToggleFlightEvent event) {
        if (!plugin.getConfig().getBoolean("checks.fly.enabled", true)) return;
        Player p = event.getPlayer();
        // If player isn't allowed to fly but toggles flight, that's suspicious
        if (!p.getAllowFlight()) {
            flagViolation(p, "fly", flyKickThreshold);
        }
    }

    private void flagViolation(Player p, String type, int threshold) {
        UUID id = p.getUniqueId();
        int v = violations.getOrDefault(id, 0) + 1;
        violations.put(id, v);
        if (announce) {
            Bukkit.getLogger().info("[AntiCheat] " + p.getName() + " suspected of " + type + " (" + v + " violations)");
        }
        if (v >= threshold && kickOnExceed) {
            p.kickPlayer(plugin.getConfig().getString("punish.kick_message", "Kicked: suspected cheating (AntiCheat)"));
        } else {
            // warn player quietly (or could be logged)
            p.sendMessage("§c[AntiCheat] Suspicious " + type + " detected (" + v + "/" + threshold + ")");
        }
    }
}
