package me.automace;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import org.lwjgl.glfw.GLFW;

public class AutoMaceMod implements ClientModInitializer {

    public static boolean ENABLED = false;
    private KeyBinding toggleKey;
    private KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("Toggle AutoMace", GLFW.GLFW_KEY_B, "AutoMace")
        );
        menuKey = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("Open AutoMace Menu", GLFW.GLFW_KEY_N, "AutoMace")
        );

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.wasPressed()) {
                ENABLED = !ENABLED;
            }
            while (menuKey.wasPressed()) {
                // TODO: open GUI
            }
        });
    }
}
